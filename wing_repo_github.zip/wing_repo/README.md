# Wing Setup & Shows
### Behringer Wing Rack — 11th Street Disciples / Malice in Wonderland

This repository contains all Wing Rack presets, routing configurations, show files, and accessibility app code for the 7-piece band production system.

---

## Repository Structure

```
Wing_setup_shows/
├── presets/
│   ├── vocals/
│   ├── drums/
│   ├── instruments/
│   └── hum_removal/
├── routing/
│   ├── input_patch/
│   └── output_patch/
├── snippets/
├── shows/
├── docs/
└── apps/
```

---

## System Overview

| Parameter | Value |
|---|---|
| Console | Behringer Wing Rack |
| Firmware | v2.1 |
| Inputs | 27 channels |
| Outputs | 8 XLR monitor mixes |
| GPIO | 2 assignments |
| Capture | 64ch WING-LIVE dual SD |

### Input Map
| Channel | Source |
|---|---|
| Ch 1 | Kick In |
| Ch 2 | Kick Out |
| Ch 3 | Snare Top |
| Ch 4 | Snare Bottom |
| Ch 5 | Tom High |
| Ch 6 | Tom Mid |
| Ch 7 | Tom Floor |
| Ch 8 | Overhead L |
| Ch 9 | Overhead R |
| Ch 10 | Hi-Hat |
| Ch 11 | Bass DI |
| Ch 12 | Electric Guitar L |
| Ch 13 | Electric Guitar R |
| Ch 14 | Acoustic Guitar |
| Ch 15 | Lead Vocal |
| Ch 16 | BGV 1 |
| Ch 17 | BGV 2 |
| Ch 18 | BGV 3 / Spare |
| Ch 19-20 | Keys Synth L/R |
| Ch 21-22 | Keys Pad L/R |
| Ch 23-24 | Aux Keys L/R |
| Ch 25-26 | Keys FX L/R |
| Ch 27 | Bass/Click (Mono) |

### Output Map
| Bus | Destination |
|---|---|
| Bus 1 | Wedge 1 |
| Bus 2 | Wedge 2 |
| Bus 3 | Wedge 3 |
| Bus 4 | Wedge 4 |
| Bus 5-6 | Keys/Bass IEM (Stereo) |
| Bus 7-8 | Drum IEM (Stereo) |

### GPIO
| Port | Function |
|---|---|
| GPIO 1 | Leslie Speed Toggle (N.O.) |
| GPIO 2 | FX Kill Switch (Latching) |
